'use client'

import SingUpForm from "./signupform";

const SingUp = () => {
  return (
    <>
      <SingUpForm />
    </>
  );
};

export default SingUp;
